<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <title>ORIKKAPA</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <h1>ORIKKAPA</h1>
    <p>Aplicació per ajudar persones amb TDAH a organitzar el seu dia a dia</p>
</header>

<section>
    <h2>Problema</h2>
    <p>Les persones amb TDAH tenen dificultats per organitzar-se, concentrar-se i completar tasques, cosa que pot generar frustració.</p>
</section>

<section>
    <h2>Solució</h2>
    <p>ORIKKAPA ajuda a dividir tasques, establir recordatoris i mantenir una estructura simple i flexible.</p>
</section>

<section>
    <h2>Públic objectiu</h2>
    <p>Adolescents i adults amb TDAH, estudiants i professionals que necessiten millorar la seva organització.</p>
</section>

<section>
    <h2>Funcionalitats</h2>
    <ul>
        <li>Creació de tasques</li>
        <li>Recordatoris</li>
        <li>Organització simple</li>
        <li>Divisió de tasques en passos petits</li>
    </ul>
</section>

<footer>
    <p>Projecte web ORIKKAPA</p>
</footer>

</body>
</html>